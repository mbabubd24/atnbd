
import { AppState, AuthState, LedgerEntry } from '../types';

const KEYS = {
  APP_STATE: 'myaccounts_v1_state',
  AUTH: 'myaccounts_v1_auth',
};

const DEFAULT_AUTH: AuthState = {
  userId: 'admin',
  password: '1234',
  isAuthenticated: false,
};

const DEFAULT_STATE: AppState = {
  entries: [],
  suggestions: {
    workNames: [],
    categories: [],
  },
};

export const storage = {
  getAuth: (): AuthState => {
    const data = localStorage.getItem(KEYS.AUTH);
    return data ? JSON.parse(data) : DEFAULT_AUTH;
  },
  setAuth: (auth: AuthState) => {
    localStorage.setItem(KEYS.AUTH, JSON.stringify(auth));
  },
  getState: (): AppState => {
    const data = localStorage.getItem(KEYS.APP_STATE);
    return data ? JSON.parse(data) : DEFAULT_STATE;
  },
  setState: (state: AppState) => {
    localStorage.setItem(KEYS.APP_STATE, JSON.stringify(state));
  },
  exportData: (state: AppState) => {
    const dataStr = JSON.stringify(state, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `myaccounts_backup_${new Date().toISOString().split('T')[0]}.json`;

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  },
};
