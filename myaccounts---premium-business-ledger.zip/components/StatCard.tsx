
import React from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  colorClass: string;
  trend?: {
    value: string;
    isUp: boolean;
  };
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, colorClass, trend }) => {
  return (
    <div className="glass-card p-6 rounded-2xl flex flex-col gap-4 emerald-glow">
      <div className="flex justify-between items-start">
        <div className={`p-3 rounded-xl ${colorClass} bg-opacity-20`}>
          {icon}
        </div>
        {trend && (
          <span className={`text-xs font-medium ${trend.isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
            {trend.value}
          </span>
        )}
      </div>
      <div>
        <p className="text-slate-400 text-sm font-medium">{title}</p>
        <h3 className="text-2xl font-bold text-white mt-1">{value}</h3>
      </div>
    </div>
  );
};

export default StatCard;
